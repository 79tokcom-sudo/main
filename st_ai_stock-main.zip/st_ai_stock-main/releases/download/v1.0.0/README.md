# ST AI Launcher - 자동 업데이트 기능 포함

## 주요 기능

✅ 자동 업데이트 확인 및 다운로드
✅ 진행률 표시
✅ Tkinter DLL 오류 자동 해결
✅ PyInstaller 빌드 지원

## 설정 방법

### 1. 코드 수정
`st_ai_launcher_with_update.py` 파일에서 다음 부분을 수정하세요:

```python
CURRENT_VERSION = "1.0.0"  # 현재 런처 버전
UPDATE_CHECK_URL = "https://your-server.com/version.json"  # 버전 정보 URL
UPDATE_DOWNLOAD_URL = "https://your-server.com/main.app"  # 기본 다운로드 URL
MAIN_APP_PATH = "main.app"  # 실행할 프로그램 이름
```

### 2. 서버 설정

#### 2-1. version.json 파일 생성
웹 서버나 GitHub Pages에 다음 형식의 JSON 파일을 업로드하세요:

```json
{
  "version": "1.0.1",
  "download_url": "https://your-server.com/main.app",
  "release_notes": "버그 수정 및 성능 개선",
  "release_date": "2026-02-10"
}
```

#### 2-2. GitHub Releases 사용 (추천)
```
1. GitHub 저장소에 Release 생성
2. main.app 파일 업로드
3. version.json의 download_url을 Release URL로 설정
   예: https://github.com/username/repo/releases/download/v1.0.1/main.app
```

#### 2-3. 간단한 웹 서버 사용
```python
# simple_server.py
from http.server import HTTPServer, SimpleHTTPRequestHandler

class CORSRequestHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')
        super().end_headers()

if __name__ == '__main__':
    HTTPServer(('0.0.0.0', 8000), CORSRequestHandler).serve_forever()
```

### 3. PyInstaller로 빌드

#### Windows
```bash
pip install pyinstaller
pyinstaller --onefile --windowed --name "ST_AI_Launcher" st_ai_launcher_with_update.py
```

#### macOS
```bash
pip install pyinstaller
pyinstaller --onefile --windowed --name "ST_AI_Launcher" st_ai_launcher_with_update.py
# 생성된 app을 Applications에 복사
```

## 동작 방식

1. **런처 시작** → 자동으로 업데이트 확인
2. **새 버전 발견** → 사용자에게 업데이트 확인 메시지
3. **업데이트 승인** → 진행률 표시하며 다운로드
4. **다운로드 완료 (100%)** → 자동으로 main.app 실행
5. **런처 종료** → 메인 프로그램만 실행 중

## 버전 관리

### 버전 번호 형식
`Major.Minor.Patch` (예: 1.0.1)

- **Major**: 주요 변경사항
- **Minor**: 기능 추가
- **Patch**: 버그 수정

### 새 버전 배포 방법

1. main.app 새 버전 빌드
2. 서버에 업로드
3. version.json 업데이트
   ```json
   {
     "version": "1.0.2",  // 버전 번호 증가
     "download_url": "https://your-server.com/main.app"
   }
   ```
4. 사용자가 런처 실행 시 자동 업데이트

## 문제 해결

### Q: "업데이트 확인 실패" 메시지가 나옵니다
A: 
- 인터넷 연결 확인
- UPDATE_CHECK_URL이 올바른지 확인
- 서버가 실행 중인지 확인

### Q: 다운로드는 되는데 실행이 안 됩니다
A:
- MAIN_APP_PATH가 올바른지 확인
- 파일 실행 권한 확인 (macOS/Linux)
- 백신 프로그램 확인

### Q: 진행률이 0%에서 멈춥니다
A:
- 서버의 Content-Length 헤더 확인
- 파일이 실제로 존재하는지 확인

## 고급 설정

### HTTPS 인증서 검증 비활성화 (개발용)
```python
import ssl
ssl._create_default_https_context = ssl._create_unverified_context
```

### 프록시 사용
```python
proxy_handler = urllib.request.ProxyHandler({'http': 'http://proxy:8080'})
opener = urllib.request.build_opener(proxy_handler)
urllib.request.install_opener(opener)
```

## 라이선스
MIT License
