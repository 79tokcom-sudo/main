# -*- coding: utf-8 -*-
"""
ST AI Launcher with Auto Update
- Tkinter DLL (_tkinter) 오류 자동 해결
- PyInstaller onefile / onedir 대응
- 자동 업데이트 기능
"""
import os
import sys
import json
import urllib.request
import urllib.error
import shutil
import threading
from pathlib import Path

# ===============================
# 1. Tkinter DLL 경로 자동 보정
# ===============================
def _fix_tkinter_paths():
    """
    PyInstaller 실행 시 tcl/tk 경로를 못 찾는 문제 해결
    """
    base_dir = getattr(sys, "_MEIPASS", os.path.abspath(os.path.dirname(__file__)))
    tcl_path = os.path.join(base_dir, "tcl")
    tk_path  = os.path.join(base_dir, "tk")
    if os.path.isdir(tcl_path) and os.path.isdir(tk_path):
        os.environ["TCL_LIBRARY"] = tcl_path
        os.environ["TK_LIBRARY"]  = tk_path

_fix_tkinter_paths()

# ===============================
# 2. 표준 라이브러리
# ===============================
import tkinter as tk
from tkinter import ttk, messagebox

# ===============================
# 3. 설정
# ===============================
CURRENT_VERSION = "1.0.0"  # 현재 버전
UPDATE_CHECK_URL = "https://your-server.com/version.json"  # 버전 정보 URL
UPDATE_DOWNLOAD_URL = "https://your-server.com/main.app"  # 다운로드 URL
MAIN_APP_PATH = "main.app"  # 실행할 메인 앱 경로

# ===============================
# 4. 업데이트 체커
# ===============================
class UpdateChecker:
    def __init__(self, parent):
        self.parent = parent
        
    def check_for_updates(self):
        """서버에서 최신 버전 정보 확인"""
        try:
            with urllib.request.urlopen(UPDATE_CHECK_URL, timeout=5) as response:
                data = json.loads(response.read().decode('utf-8'))
                latest_version = data.get("version", CURRENT_VERSION)
                download_url = data.get("download_url", UPDATE_DOWNLOAD_URL)
                
                if self._is_newer_version(latest_version):
                    return True, latest_version, download_url
                return False, CURRENT_VERSION, None
        except Exception as e:
            print(f"업데이트 확인 실패: {e}")
            return False, CURRENT_VERSION, None
    
    def _is_newer_version(self, latest):
        """버전 비교 (예: "1.0.1" > "1.0.0")"""
        try:
            current_parts = [int(x) for x in CURRENT_VERSION.split(".")]
            latest_parts = [int(x) for x in latest.split(".")]
            return latest_parts > current_parts
        except:
            return False
    
    def download_update(self, url, progress_callback):
        """업데이트 파일 다운로드"""
        try:
            temp_path = "main.app.tmp"
            
            # 다운로드
            with urllib.request.urlopen(url, timeout=30) as response:
                total_size = int(response.headers.get('Content-Length', 0))
                downloaded = 0
                
                with open(temp_path, 'wb') as f:
                    while True:
                        chunk = response.read(8192)
                        if not chunk:
                            break
                        f.write(chunk)
                        downloaded += len(chunk)
                        
                        if total_size > 0:
                            progress = int((downloaded / total_size) * 100)
                            progress_callback(progress)
            
            # 기존 파일 백업
            if os.path.exists(MAIN_APP_PATH):
                backup_path = MAIN_APP_PATH + ".backup"
                if os.path.exists(backup_path):
                    os.remove(backup_path)
                shutil.move(MAIN_APP_PATH, backup_path)
            
            # 새 파일로 교체
            shutil.move(temp_path, MAIN_APP_PATH)
            
            # 실행 권한 부여 (macOS/Linux)
            if sys.platform != "win32":
                os.chmod(MAIN_APP_PATH, 0o755)
            
            return True
        except Exception as e:
            print(f"다운로드 실패: {e}")
            return False

# ===============================
# 5. 메인 앱
# ===============================
class LauncherApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ST AI Launcher")
        self.geometry("420x320")
        self.resizable(False, False)
        
        self.update_checker = UpdateChecker(self)
        self.is_updating = False
        
        self._build_ui()
        
        # 시작 시 자동 업데이트 확인
        self.after(500, self.check_update)
    
    def _build_ui(self):
        frame = ttk.Frame(self, padding=20)
        frame.pack(expand=True, fill="both")
        
        # 타이틀
        title = ttk.Label(
            frame,
            text="천신대왕 ST AI 런처",
            font=("Malgun Gothic", 14, "bold")
        )
        title.pack(pady=(0, 10))
        
        # 버전 정보
        self.version_label = ttk.Label(
            frame,
            text=f"버전: {CURRENT_VERSION}",
            font=("Malgun Gothic", 9)
        )
        self.version_label.pack(pady=(0, 20))
        
        # 상태 메시지
        self.status_label = ttk.Label(
            frame,
            text="준비됨",
            font=("Malgun Gothic", 9),
            foreground="green"
        )
        self.status_label.pack(pady=(0, 10))
        
        # 진행률 바
        self.progress = ttk.Progressbar(
            frame,
            mode='determinate',
            length=300
        )
        self.progress.pack(pady=(0, 20))
        
        # 실행 버튼
        self.run_btn = ttk.Button(
            frame,
            text="프로그램 실행",
            command=self.run_program
        )
        self.run_btn.pack(fill="x", pady=5)
        
        # 수동 업데이트 확인 버튼
        self.update_btn = ttk.Button(
            frame,
            text="업데이트 확인",
            command=self.check_update
        )
        self.update_btn.pack(fill="x", pady=5)
        
        # 종료 버튼
        exit_btn = ttk.Button(
            frame,
            text="종료",
            command=self.destroy
        )
        exit_btn.pack(fill="x", pady=5)
    
    def check_update(self):
        """업데이트 확인"""
        if self.is_updating:
            return
        
        self.set_status("업데이트 확인 중...", "blue")
        self.disable_buttons()
        
        def check_thread():
            needs_update, version, download_url = self.update_checker.check_for_updates()
            
            self.after(0, lambda: self.handle_update_check(needs_update, version, download_url))
        
        threading.Thread(target=check_thread, daemon=True).start()
    
    def handle_update_check(self, needs_update, version, download_url):
        """업데이트 확인 결과 처리"""
        if needs_update:
            response = messagebox.askyesno(
                "업데이트 사용 가능",
                f"새 버전({version})이 있습니다.\n지금 업데이트하시겠습니까?"
            )
            if response:
                self.start_update(download_url)
            else:
                self.set_status("업데이트 취소됨", "orange")
                self.enable_buttons()
        else:
            self.set_status("최신 버전입니다", "green")
            self.enable_buttons()
    
    def start_update(self, download_url):
        """업데이트 시작"""
        self.is_updating = True
        self.set_status("업데이트 다운로드 중...", "blue")
        self.progress['value'] = 0
        
        def download_thread():
            success = self.update_checker.download_update(
                download_url,
                self.update_progress
            )
            self.after(0, lambda: self.finish_update(success))
        
        threading.Thread(target=download_thread, daemon=True).start()
    
    def update_progress(self, percent):
        """진행률 업데이트"""
        self.after(0, lambda: self._update_progress_ui(percent))
    
    def _update_progress_ui(self, percent):
        """UI에 진행률 반영"""
        self.progress['value'] = percent
        self.set_status(f"다운로드 중... {percent}%", "blue")
    
    def finish_update(self, success):
        """업데이트 완료"""
        self.is_updating = False
        
        if success:
            self.progress['value'] = 100
            self.set_status("업데이트 완료! 프로그램 실행 중...", "green")
            messagebox.showinfo("업데이트 완료", "업데이트가 완료되었습니다.\n프로그램을 실행합니다.")
            self.after(500, self.run_program)
        else:
            self.set_status("업데이트 실패", "red")
            messagebox.showerror("오류", "업데이트 다운로드에 실패했습니다.")
            self.enable_buttons()
            self.progress['value'] = 0
    
    def run_program(self):
        """메인 프로그램 실행"""
        if not os.path.exists(MAIN_APP_PATH):
            messagebox.showerror(
                "오류",
                f"{MAIN_APP_PATH} 파일을 찾을 수 없습니다.\n업데이트를 먼저 진행해주세요."
            )
            return
        
        try:
            if sys.platform == "win32":
                os.startfile(MAIN_APP_PATH)
            elif sys.platform == "darwin":  # macOS
                os.system(f"open '{MAIN_APP_PATH}'")
            else:  # Linux
                os.system(f"xdg-open '{MAIN_APP_PATH}'")
            
            self.set_status("프로그램 실행됨", "green")
            # 런처 종료
            self.after(1000, self.destroy)
        except Exception as e:
            messagebox.showerror("실행 오류", f"프로그램 실행 실패:\n{e}")
    
    def set_status(self, message, color="black"):
        """상태 메시지 업데이트"""
        self.status_label.config(text=message, foreground=color)
    
    def disable_buttons(self):
        """버튼 비활성화"""
        self.run_btn.config(state="disabled")
        self.update_btn.config(state="disabled")
    
    def enable_buttons(self):
        """버튼 활성화"""
        self.run_btn.config(state="normal")
        self.update_btn.config(state="normal")

# ===============================
# 6. 엔트리 포인트
# ===============================
if __name__ == "__main__":
    try:
        app = LauncherApp()
        app.mainloop()
    except Exception as e:
        import traceback
        messagebox.showerror(
            "치명적 오류",
            f"프로그램 실행 중 오류 발생:\n\n{e}\n\n{traceback.format_exc()}"
        )
