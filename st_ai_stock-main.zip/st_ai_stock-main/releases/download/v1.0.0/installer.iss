; Inno Setup script placeholder
